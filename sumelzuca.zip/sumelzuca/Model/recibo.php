<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";

class DbRecibo extends DB

{


	public function getRecibo($limit)
	
	{
	
		return $this->select("SELECT * FROM factura ORDER BY idfactura ASC LIMIT ?", ["i", $limit]);
	
	}
	
	
	
	
	public function insertRecibo($codigo,$total,$cliente,$proveedor,$monto,$tipo)
	{
		
		return $this->insert("INSERT INTO `factura`(`idfactura`, `codigocliente`,`idcliente`,
									`idproveedor`, `montofactura`, `tipofactura`)
									 VALUES (NULL, ?,?,?,?,?,?)", 
									 ["siiidi", $codigo,$total,$cliente,$proveedor,$monto,$tipo]);	
	}
	
	
	
	public function deleteRecibo($id)
	{
		
		return $this->delete("DELETE FROM `factura` WHERE `factura`.`idfactura` = ? ",["i", $id]);	
		
	}
	
	
	public function updateRecibo($codigo,$total,$cliente,$proveedor,$monto,$tipo ,$id)
	{
		
		return $this->update("UPDATE `factura` SET 
											`idtotal`=? , `codigofactura`= ? ,
											`clientesidclientes`= ? ,`idproveedor`= ? ,
											`montofactura`= ? ,`tipofactura`= ?  WHERE ?",
											["siiidii",$codigo,$total,$cliente,$proveedor,$monto,$tipo,$id]);
		
	}

}
