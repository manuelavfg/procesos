<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";

class DbUsuario extends DB

{


	public function getUsuario($limit)
	
	{
	
		return $this->select("SELECT * FROM usuarios ORDER BY idusuario ASC LIMIT ?", ["i", $limit]);
	 
	}
	
	
	public function insertUsuario($nombre,$contrasena,$telefono,$correo)
	{
		
		return $this->insert("INSERT INTO `usuarios`(`idusuario`, `nombreusuario`, `contrasenausuarios`, 
									`correousuario`, `telefonousuario`, `idpermiso`)
									VALUES (NULL, ?, ?,?,?)", ["ssssi", $nombre, $contrasena, $correo, $telefono]);	
		
	}
	
	
	public function deleteUsuario($id)
	{
		
		return $this->delete("DELETE FROM `usuarios` WHERE `usuarios`.`idusuario` = ? ",["i", $id]);	
		
	}
	
	
	public function updateUsuario($id, $nombre, $contrasena, $telefono, $correo)
	{
		
		return $this->update("UPDATE `usuarios` SET `nombreusuario`= ?,`contrasenausuarios`= ?,
									`correousuario`= ?,`telefonousuario`= ?,`idpermiso`= 1 WHERE ?", 
									["ssssi", $nombre, $contrasena, $correo, $telefono , $id]);
		
	}
	
	public function LoginUsuario($correo, $contrasena)
	{
		return $this->select("SELECT correousuario, contrasenausuarios FROM usuarios WHERE correousuario = ? AND contrasenausuarios = ?; ", ["ss", $correo,$contrasena]);
	}

}
