<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";

class DbCuentasCobrar extends DB

{


	public function getCuentasCobrar($limit, $offset)
	
	{
	
		return $this->select("SELECT * FROM cuentascobrar ORDER BY idcuentascobrar ASC LIMIT ? OFFSET ?", ["ii", $limit, $offset]);
	
	}
	
	
	public function insertCuentasCobrar($codigo,$cliente,$factura)
	{
		
		return $this->insert("INSERT INTO `cuentascobrar`(`idcuentascobrar`, `codigocuentascobrar`, `idcliente`, `idfactura`)
		VALUES (NULL,?, ?, ?)",
		["sii",$codigo,$cliente,$factura]);	
		
	}

	public function getTable($limit,$offset)
	{
		return $this->select("SELECT c.idcuentascobrar, c.codigocuentascobrar, cl.nombreclientes ,f.codigofactura
        FROM cuentascobrar c 
        INNER JOIN clientes cl on 
        c.idcliente = cl.idclientes
        INNER JOIN factura f on
        c.idfactura = f.idfactura ORDER BY c.idcuentascobrar ASC LIMIT ? OFFSET ?", ["ii", $limit, $offset]);
	}

}
