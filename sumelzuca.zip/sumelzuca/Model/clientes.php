<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";

class DbCliente extends DB

{


	public function getCliente($limit)
	
	{
	
		return $this->select("SELECT * FROM clientes ORDER BY idclientes ASC LIMIT ?", ["i", $limit]);
	
	}
	
	
	public function insertCliente($nombre,$correo,$rif,$dir,$telf)
	{
		
		return $this->insert("INSERT INTO `clientes`
									(`idclientes`, `nombreclientes`,
									`rifclientes`, `direccionclientes`,
									`correoclientes`, `telefonoclientes`)
									VALUES (NULL, ?,?,?,?,?)", ["sssss", $nombre, $rif,$dir,$correo,$telf]);	
	}
	
	
	public function deleteCliente($id)
	{
		
		return $this->delete("DELETE FROM `clientes` WHERE `clientes`.`idclientes` = ? ",["i", $id]);	
		
	}
	
	
	public function updateCliente($nombre,$correo,$rif,$dir,$telf, $id)
	{
		
		return $this->update("UPDATE `clientes` SET `nombreclientes`= ?,`rifclientes`=?,
									`direccionclientes`= ?,`correoclientes` = ?,`telefonoclientes`= ?
									 WHERE ?", ["sssssi", $nombre, $correo,$rif,$dir,$telf,$id]);
		
	}

}
