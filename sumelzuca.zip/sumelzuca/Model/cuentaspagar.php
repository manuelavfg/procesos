<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";

class DbCuentasPagar extends DB

{


	public function getCuentasPagar($limit, $offset)
	
	{
	
		return $this->select("SELECT * FROM cuentaspagar ORDER BY idcuentaspagar ASC LIMIT ? OFFSET ?", ["ii", $limit, $offset]);
	
	}
	
	
	public function insertCuentasPagar($codigo,$proveedor,$factura)
	{
		
		return $this->insert("INSERT INTO `cuentaspagar`(`idcuentaspagar`, `codigocuentaspagar`, `idproveedor`, `idfactura`)
		VALUES (NULL,?, ?, ?)",
		["sii",$codigo,$proveedor,$factura]);	
		
	}


	public function getTable($limit,$offset)
	{
		return $this->select("SELECT c.idcuentaspagar, c.codigocuentaspagar, cl.nombreproveedor ,f.codigofactura
        FROM cuentaspagar c 
        INNER JOIN proveedor cl on 
        c.idcliente = cl.idproveedor
        INNER JOIN factura f on
        c.idfactura = f.idfactura ORDER BY c.idcuentaspagar ASC LIMIT ? OFFSET ?", ["ii", $limit, $offset]);
	}

}
