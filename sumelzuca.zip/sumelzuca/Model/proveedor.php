<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";


class DbProveedor extends DB

{
	
	public function getProveedor($limit,$offset)
	
	{
	
		return $this->select("SELECT * FROM proveedores ORDER BY idproveedores ASC LIMIT ? OFFSET ?", ["ii", $limit,$offset]);
	
	}

	public function selectProveedor($limit)
	{

		return $this->select("SELECT nombreproveedores FROM proveedores ORDER BY idproveedores ASC LIMIT ?",["i",$limit]);

	}
	
	
	public function insertProveedor($nombre,$correo,$rif,$dir,$telf)
	{
		return $this->insert("INSERT INTO `proveedores`(`idproveedores`, `nombreproveedores`, `correoproveedor`,
						  			`rifproveedores`, `direccionproveedores`, `telefonoproveedores`)
									 VALUES (NULL, ?,?,?,?)", ["sssss", $nombre, $correo,$rif,$dir,$telf]);	
	}
	
	
	public function deleteProveedor($id)
	{
		
		return $this->delete("DELETE FROM `proveedores` WHERE `proveedores`.`idproveedores` = ? ",["i", $id]);	
		
	}
	
	
	public function updateProveedor($nombre,$correo,$rif,$dir,$telf, $id)
	{
		
		return $this->update("UPDATE `proveedores` SET `nombreproveedores`= ?,`correoproveedor`=?,
									`rifproveedores`= ?,`direccionproveedores`= ?,`telefonoproveedores`= ? WHERE ?",
									 ["sssssi", $nombre, $correo,$rif,$dir,$telf,$id]);
		
	}

}
