<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";

class DbFactura extends DB

{


	public function getFactura($limit)
	
	{
	
		return $this->select("SELECT f.codigofactura,pr.nombreproveedores, f.tipofactura FROM factura f INNER JOIN proveedores pr on f.idproveedorfactura = pr.idproveedores ORDER BY idfactura ASC LIMIT ?", ["i", $limit]);
	
	}
	
	
	
	
	public function insertFactura($codigo,$cliente,$proveedor,$articulo,$tipo)
	{
		
		return $this->insert("INSERT INTO `factura`(`idfactura`, `codigofactura`, `idcliente`, `idproveedorfactura`, `idarticulofactura`, `tipofactura`)
									 VALUES (NULL, ?,?,?,?,?)", 
									 ["siiis", $codigo,$cliente,$proveedor,$articulo,$tipo]);	
	}
	
	
	
	public function deleteFactura($id)
	{
		
		return $this->delete("DELETE FROM `factura` WHERE `factura`.`idfactura` = ? ",["i", $id]);	
		
	}
	
	
	public function updateFactura($codigo,$cliente,$proveedor,$tipo ,$id)
	{
		
		return $this->update("UPDATE `factura` SET 
											 `codigofactura`= ? ,
											`clientesidclientes`= ? ,`idproveedor`= ? ,
											`tipofactura`= ?  WHERE ?",
											["siiii",$codigo,$cliente,$proveedor,$tipo,$id]);
		
	}

}
