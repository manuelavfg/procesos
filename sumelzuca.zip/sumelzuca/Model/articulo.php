<?php

require_once PROJECT_ROOT_PATH . "\Model\db.php";

class DbArticulo extends DB

{


	public function getArticulo($limit, $offset)
	
	{
	
		return $this->select("SELECT * FROM articulos ORDER BY idarticulo ASC LIMIT ? OFFSET ?", ["ii", $limit, $offset]);
	
	}



	public function selectArticulo($limit)
	{

		return $this->select("SELECT `descripcionarticulo` FROM `articulos` ORDER BY `idarticulo` ASC LIMIT ?",["i",$limit]);

	}
	
	
	
	public function getArticuloFactura($id)
	
	{
	
		return $this->select("SELECT `descripcionarticulo`, `tipoarticulo`,`existenciaarticulo`,`costoarticulo` FROM `articulos` WHERE `idarticulo`= ?; ", ["i", $id,]);
	
	}
	
	
	public function insertArticulo($nombre,$tipo, $cantidad, $codigo, $precio, $entrada,$salida,$proveedor)
	{
		
		return $this->insert("INSERT INTO `articulos`
		(`idarticulo`, `descripcionarticulo`, `tipoarticulo`, `existenciaarticulo`,
		`codigoarticulo`, `costoarticulo`, `entradaarticulo`,
		`salidaarticulo`, `idproveedor`) 
		VALUES (NULL, ?, ?, ?, ?, ?, ?,?,?)",
		["ssisdssi", $nombre, $tipo,$cantidad,$codigo,$precio,$entrada,$salida,$proveedor]);	
		
	}
	
	
	public function deleteArticulo($id)
	{
		
		return $this->delete("DELETE FROM `articulos` WHERE `idarticulo` = ? ",["i", $id]);	
		
	}
	
	
	public function updateArticulo($id, $nombre,$tipo, $cantidad, $codigo, $precio, $entrada,$salida,$proveedor)
	{
		
		return $this->update("UPDATE `articulos` SET
		`nombre` = ?, `precio` = ? WHERE `articulo`.`id` = ?;",
		 ["sdi", $nombre, $precio, $id]);
		
	}

	public function registrarArticulo($id, $cantidad, $entrada)
	{
		
		return $this->update("UPDATE `articulos` SET
		`existenciaarticulo` = existenciaarticulo + ?, `entradaarticulo ` = ? WHERE `articulo` `idarticulo` = ?;",
		 ["sdi", $cantidad, $entrada, $id]);
		
	}

}
