<?php
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: POST, GET, DELETE, PUT, PATCH, OPTIONS');
    header('Access-Control-Allow-Headers: token, Content-Type');
    header('Access-Control-Max-Age: 1728000');
    header('Content-Length: 0');
    header('Content-Type: text/plain');
    die();
}

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

require "..\bootstrap.php";

function callMethod($uri = "")
{
	$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
	$uri = explode( '/', $uri );
	

	
	$tabla = $uri[count($uri)-2];
	$metodo = $uri[count($uri)-1];
	switch($tabla)
	{
		case "articulo":
			require PROJECT_ROOT_PATH . "\Controlador\API\controladorArticulo.php";

			$objFeedController = new ControladorArticulo();

			$strMethodName = $metodo . 'Action';
			$objFeedController->{$strMethodName}();
			break;
			
		case "usuario":
				require PROJECT_ROOT_PATH . "\Controlador\API\controladorUsuario.php";
	
				$objFeedController = new ControladorUsuario();
	
				$strMethodName = $metodo . 'Action';
				$objFeedController->{$strMethodName}();
				break;
				
		case "factura":
			require PROJECT_ROOT_PATH . "\Controlador\API\controladorFactura.php";
		
			$objFeedController = new ControladorFactura();
		
			$strMethodName = $metodo . 'Action';
			$objFeedController->{$strMethodName}();
			break;
			
		case "proveedores":
			require PROJECT_ROOT_PATH . "\Controlador\API\controladorProveedor.php";
			
			$objFeedController = new ControladorProveedor();
			
			$strMethodName = $metodo . 'Action';
			$objFeedController->{$strMethodName}();
			break;
			
		case "clientes":
			require PROJECT_ROOT_PATH . "\Controlador\API\controladorCliente.php";
			
			$objFeedController = new ControladorCliente();
			
			$strMethodName = $metodo . 'Action';
			$objFeedController->{$strMethodName}();
			break;
		case "cuentasporpagar":
			require PROJECT_ROOT_PATH . "\Controlador\API\controladorCuentasPagar.php";
			
			$objFeedController = new ControladorCuentasPagar();
			
			$strMethodName = $metodo . 'Action';
			$objFeedController->{$strMethodName}();
			break;
		case "cuentasporcobrar":
			require PROJECT_ROOT_PATH . "\Controlador\API\controladorCuentasCobrar.php";
			
			$objFeedController = new ControladorCuentasCobrar();
			
			$strMethodName = $metodo . 'Action';
			$objFeedController->{$strMethodName}();
			break;
			
		default:
		echo"cagamo bro";
	}
}

callMethod($_SERVER['REQUEST_URI']);

?>