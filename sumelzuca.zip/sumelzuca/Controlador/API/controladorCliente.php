<?php
header('Access-Control-Allow-Origin: *');
class ControladorCliente extends ControladorBase

{

	/**

* "/user/list" Endpoint - Get list of users

*/

	public function listAction()

{

	$strErrorDesc = '';

	$requestMethod = $_SERVER["REQUEST_METHOD"];
	

	$arrQueryStringParams = $this->getQueryStringParams();

	if (strtoupper($requestMethod) == 'GET') {

		try {

			$userModel = new DbCliente();

			$intLimit = 5;
			$offset = 0;

			if (isset($arrQueryStringParams['limit']) && $arrQueryStringParams['limit']) {

				$intLimit = $arrQueryStringParams['limit'];

			}

			$arrUsers = $userModel->getCliente($intLimit);

			$responseData = json_encode($arrUsers);

		} catch (Error $e) {

			$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

			$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

		}

	} else {

		$strErrorDesc = 'Method not supported';

		$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

	}

	// send output

	if (!$strErrorDesc) {

		$this->sendOutput(

			$responseData,

			array('Content-Type: application/json', 'HTTP/1.1 200 OK')

		);

	} else {

		$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

			array('Content-Type: application/json', $strErrorHeader)

		);

	}

	}

	
	public function addAction()

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'POST') {

			try {

				$userModel = new DbCliente();
				$nombre = $arrQueryStringParams['nombreclientes'];
				$correo = $arrQueryStringParams['correoclientes'];
				$rif = $arrQueryStringParams['rifclientes'];
				$dir = $arrQueryStringParams['direccionclientes'];
				$telf = $arrQueryStringParams['telefonoclientes'];

				$r = $userModel->insertCliente($nombre,$correo, $rif,$dir,$telf);
				
				
				$responseData = json_encode($r);

				
			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		}
		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(
	
				$responseData,
	
				array('Content-Type: application/json', 'HTTP/1.1 200 OK')
	
			);
	
		} else {
	
			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
	
				array('Content-Type: application/json', $strErrorHeader)
	
			);
	
		}

	}
	
	
	public function deleteAction()

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'DELETE') {

			try {

				$userModel = new DbCliente();
				$a = $arrQueryStringParams['idclientes'];

				$r = $userModel->deleteCliente($a);
				$responseData = json_encode($r);

			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		} else {

			$strErrorDesc = 'Method not supported';

			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

		}

		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(

						$responseData,

				array('Content-Type: application/json', 'HTTP/1.1 200 OK')

			);

		} else {

			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

				array('Content-Type: application/json', $strErrorHeader)

			);

		}

	}
	
	
	public function updateAction() 

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'PUT') {

			try {

				$userModel = new DbCliente();
				$id = $arrQueryStringParams['idclientes'];
				$nombre = $arrQueryStringParams['nombreclientes'];
				$correo = $arrQueryStringParams['correoclientes'];
				$rif = $arrQueryStringParams['rifclientes'];
				$dir = $arrQueryStringParams['dirclientes'];
				$telf = $arrQueryStringParams['telefonoclientes'];


				$r = $userModel->updateCliente($nombre,$correo,$rif,$dir,$telf,$id);
				$responseData = json_encode($r);

			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		} else {

			$strErrorDesc = 'Method not supported';

			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

		}

		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(

						$responseData,

				array('Content-Type: application/json', 'HTTP/1.1 200 OK')

			);

		} else {

			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

				array('Content-Type: application/json', $strErrorHeader)

			);

		}

	}
}
