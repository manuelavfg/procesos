<?php
header('Access-Control-Allow-Origin: *');
class ControladorProveedor extends ControladorBase

{

	/**

* "/user/list" Endpoint - Get list of users

*/

	public function listAction()

{

	$strErrorDesc = '';

	$requestMethod = $_SERVER["REQUEST_METHOD"];
	

	$arrQueryStringParams = $this->getQueryStringParams();

	if (strtoupper($requestMethod) == 'GET') {

		try {

			$userModel = new DbProveedor();

			$intLimit = 5;
			$offset = 0;

			if (isset($arrQueryStringParams['limit']) && $arrQueryStringParams['limit']) {

				$intLimit = $arrQueryStringParams['limit'];

			}

			$arrUsers = $userModel->getProveedor($intLimit, $offset);

			$responseData = json_encode($arrUsers);

		} catch (Error $e) {

			$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

			$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

		}

	} else {

		$strErrorDesc = 'Method not supported';

		$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

	}

	// send output

	if (!$strErrorDesc) {

		$this->sendOutput(

			$responseData,

			array('Content-Type: application/json', 'HTTP/1.1 200 OK')

		);

	} else {

		$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

			array('Content-Type: application/json', $strErrorHeader)

		);

	}

	}


	public function dropdownAction()

	{
	
		$strErrorDesc = '';
	
		$requestMethod = $_SERVER["REQUEST_METHOD"];
		
	
		$arrQueryStringParams = $this->getQueryStringParams();
	
		if (strtoupper($requestMethod) == 'GET') {
	
			try {
	
				$userModel = new DbProveedor();

				$limit = $arrQueryStringParams['limit'];

	
				$arrUsers = $userModel->selectProveedor($limit);
	
				$responseData = json_encode($arrUsers);
	
			} catch (Error $e) {
	
				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';
	
				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';
	
			}
	
		} else {
	
			$strErrorDesc = 'Method not supported';
	
			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';
	
		}
	
		// send output
	
		if (!$strErrorDesc) {
	
			$this->sendOutput(
	
				$responseData,
	
				array('Content-Type: application/json', 'HTTP/1.1 200 OK')
	
			);
	
		} else {
	
			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
	
				array('Content-Type: application/json', $strErrorHeader)
	
			);
	
		}
	
		}

	
	public function addAction()

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'POST') {

			try {

				$userModel = new DbProveedor();
				$nombre = $arrQueryStringParams['nombreproveedor'];
				$correo = $arrQueryStringParams['correoproveedor'];
				$rif = $arrQueryStringParams['rifproveedor'];
				$dir = $arrQueryStringParams['direccionproveedor'];
				$telf = $arrQueryStringParams['telefonoproveedor'];

				$r = $userModel->insertProveedor($nombre,$correo, $rif,$dir,$telf);
				
				
				$responseData = json_encode($r);

				
			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		}
		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(
	
				$responseData,
	
				array('Content-Type: application/json', 'HTTP/1.1 200 OK')
	
			);
	
		} else {
	
			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
	
				array('Content-Type: application/json', $strErrorHeader)
	
			);
	
		}

	}
	
	
	public function deleteAction()

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'DELETE') {

			try {

				$userModel = new DbProveedor();
				$a = $arrQueryStringParams['idproveedores'];

				$r = $userModel->deleteProveedor($a);
				$responseData = json_encode($r);

			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		} else {

			$strErrorDesc = 'Method not supported';

			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

		}

		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(

						$responseData,

				array('Content-Type: application/json', 'HTTP/1.1 200 OK')

			);

		} else {

			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

				array('Content-Type: application/json', $strErrorHeader)

			);

		}

	}
	
	
	public function updateAction() 

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'PUT') {

			try {

				$userModel = new DbProveedor();
				$id = $arrQueryStringParams['idproveedor'];
				$nombre = $arrQueryStringParams['nombreproveedor'];
				$correo = $arrQueryStringParams['correoproveedor'];
				$rif = $arrQueryStringParams['rifproveedor'];
				$dir = $arrQueryStringParams['dirproveedor'];
				$telf = $arrQueryStringParams['telfoproveedor'];


				$r = $userModel->updateProveedor($nombre,$correo,$rif,$dir,$telf,$id);
				$responseData = json_encode($r);

			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		} else {

			$strErrorDesc = 'Method not supported';

			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

		}

		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(

						$responseData,

				array('Content-Type: application/json', 'HTTP/1.1 200 OK')

			);

		} else {

			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

				array('Content-Type: application/json', $strErrorHeader)

			);

		}

	}
}
