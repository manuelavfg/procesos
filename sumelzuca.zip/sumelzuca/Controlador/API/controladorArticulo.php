<?php
header('Access-Control-Allow-Origin: *');
class ControladorArticulo extends ControladorBase

{

	/**

* "/user/list" Endpoint - Get list of users

*/

	public function listAction()

{

	$strErrorDesc = '';

	$requestMethod = $_SERVER["REQUEST_METHOD"];
	

	$arrQueryStringParams = $this->getQueryStringParams();

	if (strtoupper($requestMethod) == 'GET') {

		try {

			$userModel = new DbArticulo();
			$offset = $arrQueryStringParams['offset'];
			$intLimit = $arrQueryStringParams['limit'];

			$arrUsers = $userModel->getArticulo($intLimit,$offset);

			$responseData = json_encode($arrUsers);

		} catch (Error $e) {

			$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

			$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

		}

	} else {

		$strErrorDesc = 'Method not supported';

		$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

	}

	// send output

	if (!$strErrorDesc) {

		$this->sendOutput(

			$responseData,

			array('Content-Type: application/json', 'HTTP/1.1 200 OK')

		);

	} else {

		$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

			array('Content-Type: application/json', $strErrorHeader)

		);

	}

	}

	public function dropdownAction()

	{
	
		$strErrorDesc = '';
	
		$requestMethod = $_SERVER["REQUEST_METHOD"];
		
	
		$arrQueryStringParams = $this->getQueryStringParams();
	
		if (strtoupper($requestMethod) == 'GET') {
	
			try {
	
				$userModel = new DbArticulo();

				$limit = $arrQueryStringParams['limit'];

	
				$arrUsers = $userModel->selectArticulo($limit);
	
				$responseData = json_encode($arrUsers);
	
			} catch (Error $e) {
	
				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';
	
				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';
	
			}
	
		} else {
	
			$strErrorDesc = 'Method not supported';
	
			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';
	
		}
	
		// send output
	
		if (!$strErrorDesc) {
	
			$this->sendOutput(
	
				$responseData,
	
				array('Content-Type: application/json', 'HTTP/1.1 200 OK')
	
			);
	
		} else {
	
			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
	
				array('Content-Type: application/json', $strErrorHeader)
	
			);
	
		}
	
		}


	public function facturaAction()

	{
	
		$strErrorDesc = '';
	
		$requestMethod = $_SERVER["REQUEST_METHOD"];
		
	
		$arrQueryStringParams = $this->getQueryStringParams();
	
		if (strtoupper($requestMethod) == 'GET') {
	
			try {
	
				$userModel = new DbArticulo();
				$intLimit = 1;
	
				$arrUsers = $userModel->getArticuloFactura($intLimit);
	
				$responseData = json_encode($arrUsers);
	
			} catch (Error $e) {
	
				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';
	
				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';
	
			}
	
		} else {
	
			$strErrorDesc = 'Method not supported';
	
			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';
	
		}
	
		// send output
	
		if (!$strErrorDesc) {
	
			$this->sendOutput(
	
				$responseData,
	
				array('Content-Type: application/json', 'HTTP/1.1 200 OK')
	
			);
	
		} else {
	
			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
	
				array('Content-Type: application/json', $strErrorHeader)
	
			);
	
		}
	
		}
	

	public function addAction()

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'POST') {

			try {

				$userModel = new DbArticulo();
				$descripcion = $arrQueryStringParams['descripcionarticulo'];
				$tipo = $arrQueryStringParams['tipoarticulo'];
				$existencia = $arrQueryStringParams['existenciaarticulo'];
				$codigo = $arrQueryStringParams['codigoarticulo'];
				$costo = $arrQueryStringParams['costoarticulo'];
				$proveedor = $arrQueryStringParams['idproveedor'];
				$entrada = null;
				$salida = null;

				$r = $userModel->insertArticulo($descripcion,$tipo, $existencia,$codigo,$costo,$entrada,$salida,$proveedor);
				
				
				$responseData = json_encode($r);

				
			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		}
		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(
	
				$responseData,
	
				array('Content-Type: application/json', 'HTTP/1.1 200 OK')
	
			);
	
		} else {
	
			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 
	
				array('Content-Type: application/json', $strErrorHeader)
	
			);
	
		}

	}
	
	
	public function deleteAction()

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'DELETE') {

			try {

				$userModel = new DbArticulo();
				$a = $arrQueryStringParams['id'];

				$r = $userModel->deleteArticulo($a);
				$responseData = json_encode($r);

			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		} else {

			$strErrorDesc = 'Method not supported';

			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

		}

		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(

						$responseData,

				array('Content-Type: application/json', 'HTTP/1.1 200 OK')

			);

		} else {

			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

				array('Content-Type: application/json', $strErrorHeader)

			);

		}

	}
	
	
	public function updateAction()

	{

		$strErrorDesc = '';

		$requestMethod = $_SERVER["REQUEST_METHOD"];

		$arrQueryStringParams = $this->getQueryStringParams();

		if (strtoupper($requestMethod) == 'PUT') {

			try {

				$userModel = new DbArticulo();
				var_dump($arrQueryStringParams);
				$id = $arrQueryStringParams['id'];
				$descripcion = $arrQueryStringParams['descripcionarticulo'];
				$tipo = $arrQueryStringParams['tipoarticulo'];
				$existencia = $arrQueryStringParams['existenciaarticulo'];
				$codigo = $arrQueryStringParams['codigoarticulo'];
				$costo = $arrQueryStringParams['costoarticulo'];
				$proveedor = $arrQueryStringParams['idproveedor'];
				$entrada = $arrQueryStringParams['entradaarticulo '];
				$salida = null;

				$r = $userModel->registrarArticulo($id,$existencia,$entrada);
				$responseData = json_encode($r);

			} catch (Error $e) {

				$strErrorDesc = $e->getMessage().'Something went wrong! Please contact support.';

				$strErrorHeader = 'HTTP/1.1 500 Internal Server Error';

			}

		} else {

			$strErrorDesc = 'Method not supported';

			$strErrorHeader = 'HTTP/1.1 422 Unprocessable Entity';

		}

		// send output

		if (!$strErrorDesc) {

			$this->sendOutput(

						$responseData,

				array('Content-Type: application/json', 'HTTP/1.1 200 OK')

			);

		} else {

			$this->sendOutput(json_encode(array('error' => $strErrorDesc)), 

				array('Content-Type: application/json', $strErrorHeader)

			);

		}

	}
}
