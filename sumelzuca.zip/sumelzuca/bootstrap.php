<?php

define("PROJECT_ROOT_PATH", __DIR__ );

// include main configuration file

require_once PROJECT_ROOT_PATH . "\inc\config.php";

// include the base controller file

require_once PROJECT_ROOT_PATH . "\Controlador\API\base.php";

// include the use model file

require_once PROJECT_ROOT_PATH . "\Model\articulo.php";

require_once PROJECT_ROOT_PATH . "\Model\usuario.php";

require_once PROJECT_ROOT_PATH . "\Model\clientes.php";

require_once PROJECT_ROOT_PATH . "\Model\proveedor.php";

require_once PROJECT_ROOT_PATH . '\Model\factura.php';

require_once PROJECT_ROOT_PATH . '\Model\recibo.php';

require_once PROJECT_ROOT_PATH . "\Model\cuentaspagar.php";

require_once PROJECT_ROOT_PATH . "\Model\cuentascobrar.php";

?>
