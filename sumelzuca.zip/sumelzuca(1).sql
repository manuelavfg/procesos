-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-02-2025 a las 21:28:10
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `sumelzuca`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE `articulos` (
  `idarticulo` int(11) NOT NULL,
  `descripcionarticulo` varchar(50) DEFAULT NULL,
  `tipoarticulo` varchar(12) NOT NULL,
  `existenciaarticulo` int(11) NOT NULL,
  `codigoarticulo` varchar(45) DEFAULT NULL,
  `costoarticulo` double DEFAULT NULL,
  `entradaarticulo` date DEFAULT NULL,
  `salidaarticulo` date DEFAULT NULL,
  `idproveedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`idarticulo`, `descripcionarticulo`, `tipoarticulo`, `existenciaarticulo`, `codigoarticulo`, `costoarticulo`, `entradaarticulo`, `salidaarticulo`, `idproveedor`) VALUES
(1, 'LAMPARA LED DE ALUMBRADO PÚBLICO 150W 6000K - IP66', 'PZA', 10, '235BKR ', 100, NULL, NULL, 1),
(2, 'LAMPARA LED DE ALUMBRADO PÚBLICO 150W 6000', 'PZA', 10, '234BKR ', 100, NULL, NULL, 1),
(3, 'FLEJE DE HIERRO GALBANIZADO CON HEBILLA', 'PZA', 2, '237BKR', 90, NULL, NULL, 1),
(12, 'Cable de cobre', 'ML', 15, 'PRO-2123', 15, NULL, NULL, 1),
(13, 'Cable de cobre', 'ML', 15, 'PRO-2123', 15, NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `idclientes` int(11) NOT NULL,
  `nombreclientes` varchar(45) DEFAULT NULL,
  `rifclientes` varchar(45) DEFAULT NULL,
  `direccionclientes` mediumtext DEFAULT NULL,
  `correoclientes` varchar(45) DEFAULT NULL,
  `telefonoclientes` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`idclientes`, `nombreclientes`, `rifclientes`, `direccionclientes`, `correoclientes`, `telefonoclientes`) VALUES
(1, 'ALCALDIA DE MARACAIBO', 'G-200006056', 'AV. 4 CON CALLE 96,EDIF. ALCALDIA DE MARACAIBO, MUNICIPIO', '', ''),
(2, 'asd', 'qwe', 'qwe', 'qwe', '789'),
(3, 'Cable de cobre', 'asdasd', 'PRO-2123', 'asdasdasd@gmail.com', '123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `config`
--

CREATE TABLE `config` (
  `idconfig` float NOT NULL,
  `nombreconfig` varchar(64) NOT NULL,
  `rifconfig` varchar(46) NOT NULL,
  `tasaconfig` float DEFAULT NULL,
  `correoconfig` varchar(32) NOT NULL,
  `crltvfactura` varchar(16) NOT NULL,
  `crltvpresupuesto` varchar(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `config`
--

INSERT INTO `config` (`idconfig`, `nombreconfig`, `rifconfig`, `tasaconfig`, `correoconfig`, `crltvfactura`, `crltvpresupuesto`) VALUES
(1, 'Suministros eléctricos del Zulia, C.A (Sumelzuca)', 'J-50206515-6', NULL, ' sumelzuca@gmail.com', 'FAC-', 'PRE-');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentascobrar`
--

CREATE TABLE `cuentascobrar` (
  `idcuentascobrar` int(11) NOT NULL,
  `codigocuentascobrar` varchar(16) NOT NULL,
  `idcliente` int(11) NOT NULL,
  `idfactura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cuentaspagar`
--

CREATE TABLE `cuentaspagar` (
  `idcuentaspagar` int(11) NOT NULL,
  `codigocuentaspagar` varchar(16) NOT NULL,
  `idproveedor` int(11) NOT NULL,
  `idfactura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `factura`
--

CREATE TABLE `factura` (
  `idfactura` int(11) NOT NULL,
  `codigofactura` varchar(32) NOT NULL,
  `numerofactura` int(42) NOT NULL,
  `idcliente` int(11) DEFAULT NULL,
  `idproveedorfactura` int(11) DEFAULT NULL,
  `idarticulofactura` int(11) DEFAULT NULL,
  `tipofactura` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `factura`
--

INSERT INTO `factura` (`idfactura`, `codigofactura`, `numerofactura`, `idcliente`, `idproveedorfactura`, `idarticulofactura`, `tipofactura`) VALUES
(5, 'asd', 0, 1, 2, 1, 'COTIZACION'),
(6, 'FACT-2025001', 0, 1, 2, 1, 'PROFORMA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permiso`
--

CREATE TABLE `permiso` (
  `idpermiso` int(11) NOT NULL,
  `cargopermiso` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `permiso`
--

INSERT INTO `permiso` (`idpermiso`, `cargopermiso`) VALUES
(1, 'admin');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `idproveedores` int(11) NOT NULL,
  `nombreproveedores` varchar(45) DEFAULT NULL,
  `correoproveedores` varchar(45) NOT NULL,
  `rifproveedores` varchar(45) DEFAULT NULL,
  `direccionproveedores` varchar(32) NOT NULL,
  `telefonoproveedores` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`idproveedores`, `nombreproveedores`, `correoproveedores`, `rifproveedores`, `direccionproveedores`, `telefonoproveedores`) VALUES
(1, 'Tecnologias avanzadas ', '', 'J-12345678-9 ', 'Av. Siempre Viva, Caracas ', '0412-345678'),
(2, 'Distribuidora el Sol', 'distribuidorasol@gmail.com', 'J-12345678-9 ', 'Av. Siempre Viva, Caracas ', '0412-3456789 ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recibo`
--

CREATE TABLE `recibo` (
  `idrecibo` int(11) NOT NULL,
  `cantidadrecibo` int(11) NOT NULL,
  `preciorecibo` float NOT NULL,
  `idarticulo` int(11) NOT NULL,
  `idfactura` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idusuario` int(11) NOT NULL,
  `nombreusuario` varchar(45) NOT NULL,
  `contrasenausuarios` varchar(45) NOT NULL,
  `correousuario` varchar(32) NOT NULL,
  `telefonousuario` varchar(32) NOT NULL,
  `idpermiso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idusuario`, `nombreusuario`, `contrasenausuarios`, `correousuario`, `telefonousuario`, `idpermiso`) VALUES
(1, 'qwe', '123', 'qwe', '', 0),
(2, 'usuario', '123', 'usuario1@gmail.com', '123', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`idarticulo`),
  ADD KEY `fk_articulos_proveedores1_idx` (`idproveedor`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`idclientes`),
  ADD UNIQUE KEY `idclientes_UNIQUE` (`idclientes`);

--
-- Indices de la tabla `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`idconfig`);

--
-- Indices de la tabla `cuentascobrar`
--
ALTER TABLE `cuentascobrar`
  ADD PRIMARY KEY (`idcuentascobrar`),
  ADD UNIQUE KEY `idcuentascobrar_UNIQUE` (`idcuentascobrar`),
  ADD KEY `fk_cuentascobrar_clientes1_idx` (`idcliente`),
  ADD KEY `fk_cuentascobrar_factura1_idx` (`idfactura`);

--
-- Indices de la tabla `cuentaspagar`
--
ALTER TABLE `cuentaspagar`
  ADD PRIMARY KEY (`idcuentaspagar`) USING BTREE,
  ADD UNIQUE KEY `idcuentaspagar_UNIQUE` (`idcuentaspagar`),
  ADD KEY `fk_cuentaspagar_proveedores1_idx` (`idproveedor`),
  ADD KEY `fk_factura2` (`idfactura`);

--
-- Indices de la tabla `factura`
--
ALTER TABLE `factura`
  ADD PRIMARY KEY (`idfactura`),
  ADD KEY `fk_factura_clientes1_idx` (`idcliente`),
  ADD KEY `fk_articulo` (`idarticulofactura`),
  ADD KEY `fk_facturarecibo` (`idproveedorfactura`);

--
-- Indices de la tabla `permiso`
--
ALTER TABLE `permiso`
  ADD PRIMARY KEY (`idpermiso`),
  ADD UNIQUE KEY `idpermiso_UNIQUE` (`idpermiso`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`idproveedores`),
  ADD UNIQUE KEY `idproveedores_UNIQUE` (`idproveedores`);

--
-- Indices de la tabla `recibo`
--
ALTER TABLE `recibo`
  ADD PRIMARY KEY (`idrecibo`),
  ADD KEY `fk_articulorecibo` (`idarticulo`),
  ADD KEY `id_factura` (`idfactura`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idusuario`),
  ADD UNIQUE KEY `idusuarios_UNIQUE` (`idusuario`),
  ADD KEY `fk_usuarios_permiso1_idx` (`idpermiso`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `articulos`
--
ALTER TABLE `articulos`
  MODIFY `idarticulo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `idclientes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `config`
--
ALTER TABLE `config`
  MODIFY `idconfig` float NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cuentascobrar`
--
ALTER TABLE `cuentascobrar`
  MODIFY `idcuentascobrar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `cuentaspagar`
--
ALTER TABLE `cuentaspagar`
  MODIFY `idcuentaspagar` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `factura`
--
ALTER TABLE `factura`
  MODIFY `idfactura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `permiso`
--
ALTER TABLE `permiso`
  MODIFY `idpermiso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `idproveedores` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `recibo`
--
ALTER TABLE `recibo`
  MODIFY `idrecibo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD CONSTRAINT `fk_proveedores` FOREIGN KEY (`idproveedor`) REFERENCES `proveedores` (`idproveedores`) ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cuentascobrar`
--
ALTER TABLE `cuentascobrar`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`idcliente`) REFERENCES `clientes` (`idclientes`),
  ADD CONSTRAINT `fk_factura` FOREIGN KEY (`idfactura`) REFERENCES `factura` (`idfactura`);

--
-- Filtros para la tabla `cuentaspagar`
--
ALTER TABLE `cuentaspagar`
  ADD CONSTRAINT `fk_factura2` FOREIGN KEY (`idfactura`) REFERENCES `factura` (`idfactura`),
  ADD CONSTRAINT `fk_proveedores2` FOREIGN KEY (`idproveedor`) REFERENCES `proveedores` (`idproveedores`);

--
-- Filtros para la tabla `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `fk_articulo` FOREIGN KEY (`idarticulofactura`) REFERENCES `articulos` (`idarticulo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_clientes2` FOREIGN KEY (`idcliente`) REFERENCES `clientes` (`idclientes`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_facturarecibo` FOREIGN KEY (`idproveedorfactura`) REFERENCES `proveedores` (`idproveedores`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `recibo`
--
ALTER TABLE `recibo`
  ADD CONSTRAINT `fk_articulorecibo` FOREIGN KEY (`idarticulo`) REFERENCES `articulos` (`idarticulo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `id_factura` FOREIGN KEY (`idfactura`) REFERENCES `factura` (`idfactura`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
